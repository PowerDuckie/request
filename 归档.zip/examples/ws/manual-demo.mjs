import { wsManualSession, createManualSession } from "../../dist/index.js";

const url = process.env.WS_URL ?? "ws://127.0.0.1:4300";

// The protocol-specific factory and the unified entry return the same object.
const session = wsManualSession({ url });

// Or: createManualSession({ kind: "websocket", url });

// 1. Manual connect.
await session.open();
console.log("state after open:", session.state);

// 2. Manual text send.
await session.send("Hello WebSocket", { delayMs: 100 });

// 3. Manual JSON send (serialized to text).
await session.send({ type: "hello", message: "manual-json" }, { delayMs: 100 });

// 4. Manual binary send.
await session.send(Buffer.from([0x01, 0x02, 0x03]), { binary: true });

// Give the peer a moment to answer.
await new Promise((resolve) => setTimeout(resolve, 1200));

// 5. Manual close (graceful handshake, then socket teardown).
await session.close({ code: 1000, reason: "manual demo completed" });
await session.waitForClose();

console.log("state after close:", session.state);
console.log("events:", JSON.stringify(session.events, null, 2));
