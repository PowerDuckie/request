import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { createMcpStdioSession, createManualSession } from "../../dist/index.js";

const here = dirname(fileURLToPath(import.meta.url));
const serverScript = join(here, "server.mjs");

// Transport-aware manual session, spawned process included.
const session = createMcpStdioSession({
  command: process.execPath,
  args: [serverScript], // server.mjs defaults to stdio mode
  clientInfo: { name: "stdio-demo", version: "1.0.0" },
  timeoutMs: 20_000,
});

// Same object via the unified entry:
// createManualSession({ kind: "mcp", transport: "stdio", command: process.execPath, args: [serverScript] })

/** Servers legitimately lack prompts/resources; report instead of crashing. */
async function attempt(label, fn) {
  try {
    const value = await fn();
    console.log(`${label}:`, JSON.stringify(value, null, 2));
    return value;
  } catch (e) {
    console.log(`${label}: unavailable - ${e?.message ?? e}`);
    return undefined;
  }
}

try {
  await session.open();
  console.log("opened, state:", session.state);
  console.log("serverInfo:", JSON.stringify(session.serverInfo));
  console.log("protocolVersion:", session.protocolVersion);

  const tools = await attempt("tools", () =>
    session.listTools().then((r) => r.items),
  );
  await attempt("prompts", () => session.listPrompts().then((r) => r.items));
  await attempt("resources", () =>
    session.listResources().then((r) => r.items),
  );

  if (tools?.some((t) => t.name === "add")) {
    await attempt("add(2, 3)", () => session.callTool("add", { a: 2, b: 3 }));
  } else {
    console.log("no 'add' tool exposed, skipping call");
  }
} catch (e) {
  console.error("fatal:", e?.message ?? e);
  process.exitCode = 1;
} finally {
  await session.close();
  console.log("state after close:", session.state);
}
