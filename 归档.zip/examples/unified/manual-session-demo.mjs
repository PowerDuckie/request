import { createManualSession, createDebugger } from "../../dist/index.js";

// One factory for every connect-first protocol. `kind` routes internally;
// the returned object still exposes the protocol's full contract.
async function tryOpen(label, session) {
  try {
    await session.open();
    console.log(`${label}: open, state=${session.state}`);
    return true;
  } catch (e) {
    console.log(`${label}: open failed - ${e?.message ?? e}`);
    return false;
  }
}

// WebSocket
const ws = createManualSession({
  kind: "websocket",
  url: process.env.WS_URL ?? "ws://127.0.0.1:4300",
});
if (await tryOpen("websocket", ws)) {
  await ws.send({ ping: Date.now() }, { delayMs: 100 });
  await ws.close({ code: 1000, reason: "done" });
}

// MCP over Streamable HTTP (no server running? open() fails gracefully).
const mcp = createManualSession({
  kind: "mcp",
  endpoint: process.env.MCP_URL ?? "http://127.0.0.1:4200/mcp",
  timeoutMs: 10_000,
});
if (await tryOpen("mcp/http", mcp)) {
  const tools = await mcp.listTools().then((r) => r.items);
  console.log("mcp/http tools:", tools.map((t) => t.name).join(", "));
  await mcp.close();
}

// gRPC (proto tree; descriptor loads lazily inside open()).
const grpc = createManualSession({
  kind: "grpc",
  address: process.env.GRPC_ADDRESS ?? "127.0.0.1:50051",
  protoPaths: [new URL("../grpc/proto", import.meta.url).pathname],
  service: "demo.echo.Echo",
  method: "Say",
});
if (await tryOpen("grpc", grpc)) {
  await grpc.send({ text: "hello unified" });
  console.log("grpc kind:", grpc.kind, "source:", grpc.source);
  await grpc.close();
}

// SSE early detection: the UI switches to a list the moment headers arrive.
const pk = createDebugger();
const spec = {
  openapi: "3.2.0",
  info: { title: "sse", version: "1" },
  paths: {
    "/chat/completions": {
      post: {
        operationId: "streamChat",
        responses: { "200": { description: "ok" } },
      },
    },
  },
};
const baseUrl = process.env.SSE_URL ?? "http://127.0.0.1:4000/v1";
const result = await pk.send({
  spec,
  target: { operationId: "streamChat" },
  serverUrl: baseUrl,
  values: { body: { messages: [{ role: "user", content: "hi" }] } },
  maxEvents: 10,
  onResponseStart: (info) => {
    // Fired before the first event; decide render mode right here.
    console.log("early decision:", info.protocol, "streaming:", info.streaming);
  },
  onEvent: (event) => console.log("  event:", event.data.slice(0, 60)),
});
console.log("sse events:", result.response.events?.length ?? 0);
