import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import {
  discover,
  describeMethod,
  grpcCall,
  listServices,
  buildCredentialsAsync,
} from "../../dist/index.js";

const here = dirname(fileURLToPath(import.meta.url));
const ADDRESS = process.env.ADDRESS ?? "127.0.0.1:50051";
const protoRoot = join(here, "proto");

/** Source A: local proto tree. Pass the directory; it is walked and merged. */
const viaProto = {
  address: ADDRESS,
  protoPaths: [protoRoot],
  service: "demo.echo.Echo",
  method: "Say",
};

console.log("=== proto ===");

const discovered = await discover(viaProto);
console.log(
  `discovered ${discovered.services.length} service(s):`,
  discovered.services.map((s) => s.name),
);

const detail = await describeMethod(
  { address: ADDRESS, protoPaths: [protoRoot] },
  "demo.echo.Echo",
  "Say",
);
console.log("describeMethod:", detail.service, "->", detail.kind);

// Reflection needs the server to expose the reflection service; report the
// gap instead of crashing when it is not available.
try {
  const services = await listServices({ address: ADDRESS, reflection: true });
  console.log("listServices:", services.names ?? services);
} catch (e) {
  console.log(
    "listServices: unavailable (server reflection not enabled) -",
    e?.message ?? e,
  );
}

const credentials = await buildCredentialsAsync({ tls: false });
console.log("credentials kind:", credentials.kind);
void credentials;

const result = await grpcCall(viaProto, {
  messages: [{ text: "hello over grpc" }],
  onEvent: (event) => {
    if (event.direction === "outbound" || event.direction === "inbound") {
      console.log("  event:", event.direction, JSON.stringify(event.payload));
    }
  },
});
console.log("\nunary call:", JSON.stringify(result.messages));
console.log("status:", result.status?.codeName, result.status?.details ?? "");
console.log("truncated:", result.truncated);
