import { describe, expect, it } from "vitest";
import {
  createDebugger,
  createGrpcManualSession,
  createManualSession,
  createMcpManualSession,
  createMcpStdioSession,
  createWsManualSession,
  initializeMcpSession,
  mcpManualSession,
  wsManualSession,
} from "../src/index";
import { discoverAndWriteGrpcOperations } from "../src/protocols/grpc/openapi";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));

describe("manual session surface", () => {
  it("ws manual session exposes open/send/close methods", () => {
    const s = wsManualSession({ url: "ws://127.0.0.1:65535" });
    expect(typeof s.open).toBe("function");
    expect(typeof s.send).toBe("function");
    expect(typeof s.close).toBe("function");
    expect(s.protocol).toBe("websocket");
    expect(s.state).toBe("idle");
  });

  it("mcp manual session exposes list/call methods (http)", () => {
    const s = mcpManualSession({ endpoint: "http://127.0.0.1:1/mcp" });
    expect(typeof s.open).toBe("function");
    expect(typeof s.listTools).toBe("function");
    expect(typeof s.listPrompts).toBe("function");
    expect(typeof s.listResources).toBe("function");
    expect(typeof s.listSources).toBe("function");
    expect(typeof s.callTool).toBe("function");
    expect(s.protocol).toBe("mcp");
  });

  it("createMcpStdioSession routes to the stdio transport", () => {
    const s = createMcpStdioSession({ command: "npx", args: ["-y", "server"] });
    expect(typeof s.open).toBe("function");
    expect(typeof s.listTools).toBe("function");
  });

  it("grpc manual session factory is synchronous and lazy", () => {
    const s = createGrpcManualSession({
      address: "127.0.0.1:50051",
      protoPaths: [join(here, "../examples/grpc/proto")],
      service: "demo.echo.Echo",
      method: "Say",
    });
    expect(typeof s.open).toBe("function");
    expect(typeof s.send).toBe("function");
    expect(typeof s.close).toBe("function");
    expect(s.kind).toBeUndefined();
    expect(s.source).toBeUndefined();
    expect(s.protocol).toBe("grpc");
  });
});

describe("createManualSession unified entry", () => {
  it("routes by kind to each protocol factory", () => {
    const ws = createManualSession({
      kind: "websocket",
      url: "ws://127.0.0.1:65535",
    });
    expect(ws.protocol).toBe("websocket");

    const mcp = createManualSession({
      kind: "mcp",
      endpoint: "http://127.0.0.1:1/mcp",
    });
    expect(mcp.protocol).toBe("mcp");

    const grpc = createManualSession({
      kind: "grpc",
      address: "127.0.0.1:50051",
      protoPaths: [join(here, "../examples/grpc/proto")],
      service: "demo.echo.Echo",
      method: "Say",
    });
    expect(grpc.protocol).toBe("grpc");
  });

  it("routes mcp stdio by explicit transport", () => {
    const s = createManualSession({
      kind: "mcp",
      transport: "stdio",
      command: "npx",
    });
    expect(s.protocol).toBe("mcp");
  });

  it("rejects an unknown kind", () => {
    expect(() =>
      createManualSession({ kind: "nope" } as never),
    ).toThrowError(/Unknown manual session kind/);
  });
});

describe("openapi 3.2 write-back alignment", () => {
  it("grpc synthetic operations are written into OpenAPI", async () => {
    const spec = {
      openapi: "3.2.0",
      info: { title: "t", version: "1" },
      paths: {},
    };
    const endpoint = {
      address: "127.0.0.1:50051",
      protoPaths: [join(here, "../examples/grpc/proto")],
    };
    const out = await discoverAndWriteGrpcOperations(spec, endpoint);
    const ops = Object.values(out.spec.paths)
      .flatMap((p: any) => Object.values(p))
      .filter(Boolean);
    expect(
      ops.some((op: any) => op.operationId === "grpc_demo_echo_Echo_Say"),
    ).toBe(true);
    expect(ops.some((op: any) => op["x-protocol"] === "grpc")).toBe(true);
  });
});

describe("sse early detection", () => {
  it("reports streaming=true on the responseStart callback for an sse endpoint", async () => {
    const pk = createDebugger();
    const spec = {
      openapi: "3.2.0",
      info: { title: "sse", version: "1" },
      paths: {
        "/events": {
          get: {
            operationId: "getEvents",
            responses: { "200": { description: "ok" } },
          },
        },
      },
    };
    const http = await import("node:http");
    const server = http.createServer((_req, res) => {
      res.writeHead(200, { "content-type": "text/event-stream" });
      res.write("data: one\n\n");
      setTimeout(() => {
        res.write("data: two\n\n");
        res.end();
      }, 20);
    });
    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
    const address = server.address() as any;
    const baseUrl = `http://127.0.0.1:${address.port}`;

    const starts: any[] = [];
    const events: string[] = [];
    const result = await pk.send({
      spec,
      target: { operationId: "getEvents" },
      serverUrl: baseUrl,
      maxEvents: 5,
      onResponseStart: (info) => starts.push(info),
      onEvent: (event) => events.push(event.data),
    });

    await new Promise<void>((resolve) => server.close(() => resolve()));

    expect(starts.length).toBeGreaterThan(0);
    expect(starts[0].streaming).toBe(true);
    expect(starts[0].protocol).toBe("sse");
    expect(typeof starts[0].url).toBe("string");
    expect(events).toEqual(["one", "two"]);
    expect(result.response.events?.length).toBe(2);
  });

  it("reports streaming=false for a plain json endpoint", async () => {
    const pk = createDebugger();
    const spec = {
      openapi: "3.2.0",
      info: { title: "json", version: "1" },
      paths: {
        "/users/me": {
          get: {
            operationId: "getMe",
            responses: { "200": { description: "ok" } },
          },
        },
      },
    };
    const http = await import("node:http");
    const server = http.createServer((_req, res) => {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ name: "Ada" }));
    });
    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
    const address = server.address() as any;
    const baseUrl = `http://127.0.0.1:${address.port}`;

    const starts: any[] = [];
    const result = await pk.send({
      spec,
      target: { operationId: "getMe" },
      serverUrl: baseUrl,
      onResponseStart: (info) => starts.push(info),
    });

    await new Promise<void>((resolve) => server.close(() => resolve()));

    expect(starts.length).toBeGreaterThan(0);
    expect(starts[0].streaming).toBe(false);
    expect(starts[0].protocol).toBe("http");
    expect(result.response.body).toEqual({ name: "Ada" });
  });
});

describe("mcp discovery exports", () => {
  it("exposes the json-rpc initializer", () => {
    expect(typeof initializeMcpSession).toBe("function");
  });

  it("exposes both manual-session aliases", () => {
    expect(typeof createMcpManualSession).toBe("function");
    expect(typeof mcpManualSession).toBe("function");
  });

  it("exposes ws aliases", () => {
    expect(typeof createWsManualSession).toBe("function");
    expect(typeof wsManualSession).toBe("function");
  });
});
