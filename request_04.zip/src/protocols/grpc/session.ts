import { loadGrpc } from "./loader.js";
import { buildCredentialsChecked } from "./credentials.js";
import { resolveMethod } from "./descriptor.js";
import { buildCatalog } from "./catalog.js";
import type { GrpcSendOptions, GrpcTarget } from "./types.js";

export type GrpcManualSessionState =
  | "idle"
  | "connecting"
  | "open"
  | "closing"
  | "closed";

export interface GrpcManualSessionEvent {
  direction: "outbound" | "inbound" | "status" | "meta";
  payload?: unknown;
  status?: unknown;
  metadata?: unknown;
  at: number;
}

export interface GrpcManualSession {
  readonly warnings: string[];
  readonly state: GrpcManualSessionState;
  readonly events: GrpcManualSessionEvent[];
  open(): Promise<void>;
  send(message: unknown): Promise<void>;
  close(): Promise<void>;
  waitForClose(): Promise<void>;
}

export async function createGrpcManualSession(
  target: GrpcTarget,
  _options: GrpcSendOptions = {},
): Promise<GrpcManualSession> {
  const loaded = await loadGrpc();
  const { grpc } = loaded;

  const { credentials, warnings } = buildCredentialsChecked(target, loaded);
  const { catalog, packageDefinition } = await buildCatalog(target);
  const method = await resolveMethod(target, {
    catalog,
    packageDefinition,
  });

  if (method.kind !== "client_streaming" && method.kind !== "bidi_streaming") {
    throw new Error(
      `Manual session does not support ${method.kind} method ` +
        `"${target.service}/${method.name}"`,
    );
  }

  const definition = packageDefinition as Parameters<
    typeof grpc.loadPackageDefinition
  >[0];

  const root = grpc.loadPackageDefinition(definition) as Record<string, any>;

  let ServiceCtor: any = root;

  for (const part of target.service.split(".")) {
    ServiceCtor = ServiceCtor?.[part];
  }

  if (typeof ServiceCtor !== "function") {
    throw new Error(
      `Unable to resolve gRPC service constructor "${target.service}"`,
    );
  }

  const client = new ServiceCtor(
    target.address,
    credentials,
    target.channelOptions ?? {},
  );

  const events: GrpcManualSessionEvent[] = [];

  let state: GrpcManualSessionState = "idle";
  let call: any;

  let closePromise: Promise<void> | undefined;
  let closeResolve: (() => void) | undefined;

  let transportClosed = false;
  let responseCompleted = method.kind === "bidi_streaming";
  let finalized = false;

  const cleanupClient = (): void => {
    try {
      client.close?.();
    } catch {
      // Ignore cleanup errors.
    }
  };

  const finalize = (): void => {
    if (finalized) return;

    if (method.kind === "client_streaming") {
      if (!transportClosed || !responseCompleted) return;
    } else if (!transportClosed) {
      return;
    }

    finalized = true;
    state = "closed";

    const resolve = closeResolve;
    closeResolve = undefined;
    resolve?.();

    cleanupClient();
  };

  const forceFinalize = (): void => {
    if (finalized) return;

    finalized = true;
    state = "closed";

    const resolve = closeResolve;
    closeResolve = undefined;
    resolve?.();

    cleanupClient();
  };

  const createClosePromise = (): void => {
    closePromise = new Promise<void>((resolve) => {
      closeResolve = resolve;
    });
  };

  const createMetadata = () => {
    const metadata = new grpc.Metadata();

    for (const [key, raw] of Object.entries(target.metadata ?? {})) {
      const values = Array.isArray(raw) ? raw : [raw];

      for (const value of values) {
        metadata.add(key, value);
      }
    }

    return metadata;
  };

  const recordStatus = (status: unknown): void => {
    events.push({
      direction: "status",
      status,
      at: Date.now(),
    });
  };

  const handleTransportClose = (): void => {
    transportClosed = true;
    finalize();
  };

  const installCommonListeners = (): void => {
    call.on("metadata", (metadata: unknown) => {
      events.push({
        direction: "meta",
        metadata,
        at: Date.now(),
      });
    });

    call.on("status", (status: unknown) => {
      recordStatus(status);
    });

    call.once("error", (error: unknown) => {
      recordStatus(error);
      responseCompleted = true;
      transportClosed = true;
      forceFinalize();
    });

    call.once("close", handleTransportClose);
  };

  const open = async (): Promise<void> => {
    if (state === "open") return;

    if (state !== "idle") {
      throw new Error(`Cannot open session while state is "${state}"`);
    }

    state = "connecting";
    createClosePromise();

    try {
      const metadata = createMetadata();

      if (method.kind === "client_streaming") {
        call = client[method.name](
          metadata,
          (error: Error | null, response: unknown) => {
            if (error) {
              recordStatus(error);
            } else {
              events.push({
                direction: "inbound",
                payload: response,
                at: Date.now(),
              });
            }

            responseCompleted = true;
            finalize();
          },
        );
      } else {
        call = client[method.name](metadata);
      }

      if (!call || typeof call.write !== "function") {
        throw new Error(
          `Method "${target.service}/${method.name}" ` +
            "did not return a writable stream",
        );
      }

      installCommonListeners();

      if (method.kind === "bidi_streaming") {
        call.on("data", (payload: unknown) => {
          events.push({
            direction: "inbound",
            payload,
            at: Date.now(),
          });
        });

        call.once("end", () => {
          transportClosed = true;
          finalize();
        });
      }

      state = "open";
    } catch (error) {
      recordStatus(error);
      forceFinalize();
      throw error;
    }
  };

  const send = async (message: unknown): Promise<void> => {
    if (state === "idle") {
      await open();
    }

    if (state !== "open" || !call) {
      throw new Error(`Cannot send while session state is "${state}"`);
    }

    try {
      await new Promise<void>((resolve, reject) => {
        call.write(message, (error?: Error | null) => {
          if (error) {
            reject(error);
            return;
          }

          resolve();
        });
      });

      events.push({
        direction: "outbound",
        payload: message,
        at: Date.now(),
      });
    } catch (error) {
      recordStatus(error);
      throw error;
    }
  };

  const close = async (): Promise<void> => {
    if (state === "closed") return;

    if (state === "idle") {
      forceFinalize();
      return;
    }

    if (state === "connecting") {
      throw new Error("Cannot close while session is connecting");
    }

    if (state === "open") {
      state = "closing";

      try {
        call.end();
      } catch (error) {
        recordStatus(error);
        forceFinalize();
        throw error;
      }
    }

    await closePromise;
  };

  const waitForClose = async (): Promise<void> => {
    if (state === "closed") return;

    if (state === "idle") {
      throw new Error("Cannot wait for close before opening the session");
    }

    await closePromise;
  };

  return {
    warnings,

    get state() {
      return state;
    },

    get events() {
      return events;
    },

    open,
    send,
    close,
    waitForClose,
  };
}

export const grpcManualSession = createGrpcManualSession;
