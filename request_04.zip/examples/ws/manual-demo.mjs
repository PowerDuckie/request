import { createDebugger } from "../../dist/index.js";

let spec = {
  openapi: "3.1.0",
  info: {
    title: "WebSocket Demo",
    version: "1.0.0",
  },
  paths: {
    "/": {
      get: {
        operationId: "websocket_demo",
        "x-protocol": "websocket",
        "x-websocket": {
          url: "ws://cc.apipost.cc:6002",
          subprotocols: ["demo"],
          messages: [
            { type: "hello", message: "openapi-1" },
            { type: "hello", message: "openapi-2" },
          ],
          maxSessionMs: 500,
        },
        responses: {
          101: {
            description: "WebSocket session",
          },
        },
      },
    },
  },
};

const pk = createDebugger({
  writeBack: {
    strategy: "merge",
    requirePassingTests: false,
  },
  response: {
    includeExamples: true,
  },
});

const result = await pk.send({
  spec,
  target: { operationId: "websocket_demo" },
});

console.log(JSON.stringify(result.response.body, null, 2));

if (result.patchedSpec) {
  spec = result.patchedSpec;
}
