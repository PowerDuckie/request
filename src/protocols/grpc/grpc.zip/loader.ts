type GrpcJs = typeof import("@grpc/grpc-js");
type ProtoLoader = typeof import("@grpc/proto-loader");

export interface LoadedGrpc {
  grpc: GrpcJs;
  protoLoader: ProtoLoader;
}

let cached: LoadedGrpc | undefined;

/**
 * Loads the optional gRPC peer dependencies on first use, so that HTTP-only
 * consumers never pay for them and never need them installed.
 */
export async function loadGrpc(): Promise<LoadedGrpc> {
  if (cached) return cached;
  try {
    const [grpc, protoLoader] = await Promise.all([
      import("@grpc/grpc-js"),
      import("@grpc/proto-loader"),
    ]);
    cached = { grpc, protoLoader };
    return cached;
  } catch (cause) {
    throw new Error(
      "gRPC support requires optional peer dependencies. Install them with:\n" +
        "  npm i @grpc/grpc-js @grpc/proto-loader",
      { cause },
    );
  }
}