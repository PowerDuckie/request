/**
 * proto-loader surfaces descriptors as protobufjs toObject() output, where key
 * casing and enum representation are not guaranteed across versions. Every
 * read goes through these helpers so a representation change cannot silently
 * turn every field into undefined.
 */

export function pick<T = unknown>(
  obj: unknown,
  camel: string,
  snake: string,
): T | undefined {
  if (!obj || typeof obj !== "object") return undefined;
  const o = obj as Record<string, unknown>;
  return (o[camel] ?? o[snake]) as T | undefined;
}

export const TYPE_NAMES: Record<number, string> = {
  1: "TYPE_DOUBLE",
  2: "TYPE_FLOAT",
  3: "TYPE_INT64",
  4: "TYPE_UINT64",
  5: "TYPE_INT32",
  6: "TYPE_FIXED64",
  7: "TYPE_FIXED32",
  8: "TYPE_BOOL",
  9: "TYPE_STRING",
  10: "TYPE_GROUP",
  11: "TYPE_MESSAGE",
  12: "TYPE_BYTES",
  13: "TYPE_UINT32",
  14: "TYPE_ENUM",
  15: "TYPE_SFIXED32",
  16: "TYPE_SFIXED64",
  17: "TYPE_SINT32",
  18: "TYPE_SINT64",
};

export const LABEL_NAMES: Record<number, string> = {
  1: "LABEL_OPTIONAL",
  2: "LABEL_REQUIRED",
  3: "LABEL_REPEATED",
};

export function enumName(
  value: unknown,
  table: Record<number, string>,
): string | undefined {
  if (typeof value === "string") return value;
  if (typeof value === "number") return table[value];
  return undefined;
}

export interface FieldDescriptor {
  name: string;
  number: number;
  /** TYPE_* */
  type: string;
  /** LABEL_* */
  label: string;
  /** Fully-qualified with a leading dot, e.g. ".demo.common.Meta" */
  typeName?: string;
  jsonName?: string;
  oneofIndex?: number;
  proto3Optional: boolean;
}

export function readFields(messageType: unknown): FieldDescriptor[] {
  const raw = (pick<unknown[]>(messageType, "field", "field") ??
    []) as unknown[];
  return raw.map((f) => ({
    name: String(pick(f, "name", "name") ?? ""),
    number: Number(pick(f, "number", "number") ?? 0),
    type: enumName(pick(f, "type", "type"), TYPE_NAMES) ?? "TYPE_STRING",
    label: enumName(pick(f, "label", "label"), LABEL_NAMES) ?? "LABEL_OPTIONAL",
    typeName: pick<string>(f, "typeName", "type_name") || undefined,
    jsonName: pick<string>(f, "jsonName", "json_name") || undefined,
    oneofIndex: (() => {
      const v = pick(f, "oneofIndex", "oneof_index");
      return typeof v === "number" ? v : undefined;
    })(),
    proto3Optional:
      pick<boolean>(f, "proto3Optional", "proto3_optional") === true,
  }));
}

export function readOneofNames(messageType: unknown): string[] {
  const raw = (pick<unknown[]>(messageType, "oneofDecl", "oneof_decl") ??
    []) as unknown[];
  return raw.map((o) => String(pick(o, "name", "name") ?? ""));
}

export function readNestedTypes(messageType: unknown): unknown[] {
  return (pick<unknown[]>(messageType, "nestedType", "nested_type") ??
    []) as unknown[];
}

export function isMapEntry(messageType: unknown): boolean {
  const options = pick(messageType, "options", "options");
  return pick<boolean>(options, "mapEntry", "map_entry") === true;
}

export function readEnumValueNames(enumType: unknown): string[] {
  const raw = (pick<unknown[]>(enumType, "value", "value") ?? []) as unknown[];
  return raw.map((v) => String(pick(v, "name", "name") ?? ""));
}

export interface MethodDescriptor {
  name: string;
  inputType: string;
  outputType: string;
  clientStreaming: boolean;
  serverStreaming: boolean;
}

export function readMethods(serviceType: unknown): MethodDescriptor[] {
  const raw = (pick<unknown[]>(serviceType, "method", "method") ??
    []) as unknown[];
  return raw.map((m) => ({
    name: String(pick(m, "name", "name") ?? ""),
    inputType: String(pick(m, "inputType", "input_type") ?? ""),
    outputType: String(pick(m, "outputType", "output_type") ?? ""),
    clientStreaming:
      pick<boolean>(m, "clientStreaming", "client_streaming") === true,
    serverStreaming:
      pick<boolean>(m, "serverStreaming", "server_streaming") === true,
  }));
}
