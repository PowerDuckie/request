import {
  isMapEntry,
  readEnumValueNames,
  readFields,
  readNestedTypes,
  readOneofNames,
  pick,
  type FieldDescriptor,
} from "./descriptor-types.js";
import type { Catalog } from "./catalog.js";

export interface OneofHint {
  /** Dot path of the containing message; "" means the root message. */
  at: string;
  oneof: string;
  /** Field names in this oneof. Exactly one may be set. */
  branches: string[];
  /** Which branch the generated template pre-fills. */
  chosen: string;
}

export interface EnumHint {
  /** Dot path of the field. */
  at: string;
  /** Fully-qualified enum name. */
  enum: string;
  values: string[];
}

export interface CollectionHint {
  at: string;
  kind: "repeated" | "map";
  /** Element / value type, for UI display. */
  of: string;
}

export interface PresenceHint {
  at: string;
  /**
   * Explicit-presence field: omitting it and setting it to the zero value are
   * distinguishable on the wire, so the UI must not conflate them.
   */
  reason: "proto3_optional" | "message";
}

export interface MessageTemplate {
  /** Fully-qualified message name, no leading dot. */
  message: string;
  /** Editable example in proto3 JSON shape. */
  example: Record<string, unknown>;
  oneofs: OneofHint[];
  enums: EnumHint[];
  collections: CollectionHint[];
  presence: PresenceHint[];
  /** Truncated recursion, unresolvable types, unsupported well-known types. */
  warnings: string[];
}

const SCALAR_DEFAULTS: Record<string, unknown> = {
  TYPE_DOUBLE: 0,
  TYPE_FLOAT: 0,
  TYPE_INT32: 0,
  TYPE_UINT32: 0,
  TYPE_SINT32: 0,
  TYPE_FIXED32: 0,
  TYPE_SFIXED32: 0,
  TYPE_BOOL: false,
  TYPE_STRING: "",
  TYPE_BYTES: "",
  // 64-bit integers are strings under proto3 JSON and longs:String.
  TYPE_INT64: "0",
  TYPE_UINT64: "0",
  TYPE_SINT64: "0",
  TYPE_FIXED64: "0",
  TYPE_SFIXED64: "0",
};

/** Well-known types whose JSON form is not a plain message. */
const WELL_KNOWN: Record<string, unknown> = {
  "google.protobuf.Timestamp": "1970-01-01T00:00:00Z",
  "google.protobuf.Duration": "0s",
  "google.protobuf.Empty": {},
  "google.protobuf.StringValue": "",
  "google.protobuf.BoolValue": false,
  "google.protobuf.Int32Value": 0,
  "google.protobuf.Int64Value": "0",
  "google.protobuf.UInt32Value": 0,
  "google.protobuf.UInt64Value": "0",
  "google.protobuf.DoubleValue": 0,
  "google.protobuf.FloatValue": 0,
  "google.protobuf.BytesValue": "",
  "google.protobuf.FieldMask": "",
  "google.protobuf.Struct": {},
  "google.protobuf.Value": null,
  "google.protobuf.ListValue": [],
};

function stripDot(name: string): string {
  return name.startsWith(".") ? name.slice(1) : name;
}

function joinPath(parent: string, child: string): string {
  return parent ? `${parent}.${child}` : child;
}

export interface BuildTemplateOptions {
  /** Recursion cap for self-referential or deep messages. Default 4. */
  maxDepth?: number;
  /**
   * When true, repeated/map fields get one sample element so the user has
   * something to edit. When false they start empty. Default true.
   */
  seedCollections?: boolean;
}

interface Ctx {
  catalog: Catalog;
  maxDepth: number;
  seedCollections: boolean;
  oneofs: OneofHint[];
  enums: EnumHint[];
  collections: CollectionHint[];
  presence: PresenceHint[];
  warnings: string[];
  /** Guards against infinite recursion on cyclic message graphs. */
  stack: string[];
}

/**
 * Builds an editable proto3-JSON example for a message.
 *
 * The shape is fixed by the descriptor and is NOT user-editable; what the user
 * edits are the values, plus four structural choices that the schema itself
 * leaves open: which oneof branch is set, whether an explicit-presence field is
 * present at all, and how many elements a repeated field or map has. Those are
 * reported as hints rather than baked into the example.
 */
export function buildMessageTemplate(
  catalog: Catalog,
  messageName: string,
  options: BuildTemplateOptions = {},
): MessageTemplate {
  const ctx: Ctx = {
    catalog,
    maxDepth: options.maxDepth ?? 4,
    seedCollections: options.seedCollections !== false,
    oneofs: [],
    enums: [],
    collections: [],
    presence: [],
    warnings: [],
    stack: [],
  };

  const fq = stripDot(messageName);
  const example = buildMessage(ctx, fq, "", 0);

  return {
    message: fq,
    example: (example ?? {}) as Record<string, unknown>,
    oneofs: ctx.oneofs,
    enums: ctx.enums,
    collections: ctx.collections,
    presence: ctx.presence,
    warnings: ctx.warnings,
  };
}

function lookupMessage(ctx: Ctx, fq: string): unknown | undefined {
  const entry = ctx.catalog.symbols.get(fq);
  if (entry?.kind === "message") return entry.type;
  return undefined;
}

function lookupEnum(ctx: Ctx, fq: string): unknown | undefined {
  const entry = ctx.catalog.symbols.get(fq);
  if (entry?.kind === "enum") return entry.type;
  return undefined;
}

/**
 * Map fields are modelled in protobuf as a repeated synthetic nested message
 * with map_entry=true. Resolving it requires looking inside the *parent*
 * message's nested types, which is why nested types are searched here.
 */
function findMapEntry(
  ctx: Ctx,
  parentFq: string,
  entryFq: string,
): { keyType: string; valueField: FieldDescriptor } | undefined {
  const direct = lookupMessage(ctx, entryFq);
  const candidates: unknown[] = [];
  if (direct) candidates.push(direct);

  const parent = lookupMessage(ctx, parentFq);
  if (parent) {
    const shortName = entryFq.slice(entryFq.lastIndexOf(".") + 1);
    for (const nested of readNestedTypes(parent)) {
      if (String(pick(nested, "name", "name") ?? "") === shortName) {
        candidates.push(nested);
      }
    }
  }

  for (const candidate of candidates) {
    if (!isMapEntry(candidate)) continue;
    const fields = readFields(candidate);
    const key = fields.find((f) => f.name === "key");
    const value = fields.find((f) => f.name === "value");
    if (key && value) return { keyType: key.type, valueField: value };
  }
  return undefined;
}

function buildMessage(
  ctx: Ctx,
  fq: string,
  path: string,
  depth: number,
): Record<string, unknown> | undefined {
  if (fq in WELL_KNOWN) {
    // Handled by the caller as a scalar-like value; should not reach here.
    return {};
  }

  const type = lookupMessage(ctx, fq);
  if (!type) {
    ctx.warnings.push(
      `message "${fq}" could not be resolved at "${path || "(root)"}"; ` +
        `left as an empty object.`,
    );
    return {};
  }

  if (depth > ctx.maxDepth) {
    ctx.warnings.push(
      `recursion depth ${ctx.maxDepth} exceeded at "${path}" (${fq}); ` +
        `nested value omitted.`,
    );
    return {};
  }
  if (ctx.stack.includes(fq)) {
    ctx.warnings.push(
      `cyclic message reference at "${path}" (${fq}); nested value omitted.`,
    );
    return {};
  }

  ctx.stack.push(fq);
  try {
    const fields = readFields(type);
    const oneofNames = readOneofNames(type);
    const out: Record<string, unknown> = {};

    /** oneofIndex -> member field names, excluding synthetic proto3 optionals. */
    const realOneofs = new Map<number, FieldDescriptor[]>();
    for (const field of fields) {
      if (field.oneofIndex === undefined) continue;
      if (field.proto3Optional) continue; // synthetic wrapper, not a real oneof
      const list = realOneofs.get(field.oneofIndex) ?? [];
      list.push(field);
      realOneofs.set(field.oneofIndex, list);
    }

    const handledOneofs = new Set<number>();

    for (const field of fields) {
      const fieldPath = joinPath(path, field.name);

      if (field.proto3Optional) {
        ctx.presence.push({ at: fieldPath, reason: "proto3_optional" });
      }

      // Only the first branch of each real oneof is pre-filled.
      if (
        field.oneofIndex !== undefined &&
        !field.proto3Optional &&
        realOneofs.has(field.oneofIndex)
      ) {
        const members = realOneofs.get(field.oneofIndex)!;
        if (handledOneofs.has(field.oneofIndex)) continue;
        handledOneofs.add(field.oneofIndex);
        ctx.oneofs.push({
          at: path,
          oneof: oneofNames[field.oneofIndex] ?? `oneof_${field.oneofIndex}`,
          branches: members.map((m) => m.name),
          chosen: members[0].name,
        });
        const chosen = members[0];
        out[chosen.name] = buildFieldValue(
          ctx,
          fq,
          chosen,
          joinPath(path, chosen.name),
          depth,
        );
        continue;
      }

      out[field.name] = buildFieldValue(ctx, fq, field, fieldPath, depth);
    }

    return out;
  } finally {
    ctx.stack.pop();
  }
}

function buildFieldValue(
  ctx: Ctx,
  parentFq: string,
  field: FieldDescriptor,
  path: string,
  depth: number,
): unknown {
  const isRepeated = field.label === "LABEL_REPEATED";

  // Map field: repeated synthetic map_entry message.
  if (isRepeated && field.type === "TYPE_MESSAGE" && field.typeName) {
    const entryFq = stripDot(field.typeName);
    const mapInfo = findMapEntry(ctx, parentFq, entryFq);
    if (mapInfo) {
      ctx.collections.push({
        at: path,
        kind: "map",
        of: mapInfo.valueField.typeName
          ? stripDot(mapInfo.valueField.typeName)
          : mapInfo.valueField.type,
      });
      if (!ctx.seedCollections) return {};
      const sampleKey = mapInfo.keyType === "TYPE_STRING" ? "key" : "0";
      return {
        [sampleKey]: buildSingularValue(
          ctx,
          parentFq,
          mapInfo.valueField,
          `${path}.${sampleKey}`,
          depth,
        ),
      };
    }
  }

  if (isRepeated) {
    ctx.collections.push({
      at: path,
      kind: "repeated",
      of: field.typeName ? stripDot(field.typeName) : field.type,
    });
    if (!ctx.seedCollections) return [];
    return [buildSingularValue(ctx, parentFq, field, `${path}[0]`, depth)];
  }

  return buildSingularValue(ctx, parentFq, field, path, depth);
}

function buildSingularValue(
  ctx: Ctx,
  parentFq: string,
  field: FieldDescriptor,
  path: string,
  depth: number,
): unknown {
  if (field.type === "TYPE_ENUM" && field.typeName) {
    const fq = stripDot(field.typeName);
    const enumType = lookupEnum(ctx, fq);
    const values = enumType ? readEnumValueNames(enumType) : [];
    if (values.length === 0) {
      ctx.warnings.push(`enum "${fq}" at "${path}" has no resolvable values.`);
    } else {
      ctx.enums.push({ at: path, enum: fq, values });
    }
    // enums:String means the JSON form is the value name.
    return values[0] ?? "";
  }

  if (field.type === "TYPE_MESSAGE" || field.type === "TYPE_GROUP") {
    if (!field.typeName) {
      ctx.warnings.push(`message field at "${path}" has no type name.`);
      return {};
    }
    const fq = stripDot(field.typeName);

    if (fq === "google.protobuf.Any") {
      ctx.warnings.push(
        `"${path}" is google.protobuf.Any; its payload is passed through ` +
          `unmodified and is not validated against the descriptor.`,
      );
      return { "@type": "", value: {} };
    }
    if (fq in WELL_KNOWN) return WELL_KNOWN[fq];

    // Message-typed fields always have explicit presence.
    ctx.presence.push({ at: path, reason: "message" });
    return buildMessage(ctx, fq, path, depth + 1) ?? {};
  }

  if (field.type in SCALAR_DEFAULTS) return SCALAR_DEFAULTS[field.type];

  ctx.warnings.push(`unhandled field type ${field.type} at "${path}".`);
  return null;
}
