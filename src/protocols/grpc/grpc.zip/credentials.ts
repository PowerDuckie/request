import { loadGrpc, type LoadedGrpc } from "./loader.js";
import type { GrpcCredentialsOptions } from "./types.js";

export function buildCredentials(
  source: GrpcCredentialsOptions,
  { grpc }: LoadedGrpc,
): import("@grpc/grpc-js").ChannelCredentials {
  const tls = source.tls;
  if (tls === undefined || tls === false)
    return grpc.credentials.createInsecure();
  if (tls === true) return grpc.credentials.createSsl();

  const root = tls.rootCerts ?? null;
  const key = tls.privateKey ?? null;
  const chain = tls.certChain ?? null;

  if (tls.skipHostnameVerification) {
    return grpc.credentials.createSsl(root, key, chain, {
      checkServerIdentity: () => undefined,
    });
  }
  return grpc.credentials.createSsl(root, key, chain);
}

export async function buildCredentialsAsync(
  source: GrpcCredentialsOptions,
): Promise<import("@grpc/grpc-js").ChannelCredentials> {
  return buildCredentials(source, await loadGrpc());
}
