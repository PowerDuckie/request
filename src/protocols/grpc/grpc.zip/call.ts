import { loadGrpc } from "./loader.js";
import { buildCredentials } from "./credentials.js";
import { resolveMethod } from "./descriptor.js";
import type {
  GrpcEvent,
  GrpcResult,
  GrpcSendOptions,
  GrpcStatus,
  GrpcTarget,
  GrpcTruncatedReason,
} from "./types.js";

const CODE_NAMES: Record<number, string> = {
  0: "OK",
  1: "CANCELLED",
  2: "UNKNOWN",
  3: "INVALID_ARGUMENT",
  4: "DEADLINE_EXCEEDED",
  5: "NOT_FOUND",
  6: "ALREADY_EXISTS",
  7: "PERMISSION_DENIED",
  8: "RESOURCE_EXHAUSTED",
  9: "FAILED_PRECONDITION",
  10: "ABORTED",
  11: "OUT_OF_RANGE",
  12: "UNIMPLEMENTED",
  13: "INTERNAL",
  14: "UNAVAILABLE",
  15: "DATA_LOSS",
  16: "UNAUTHENTICATED",
};

function toStatus(code: number, details?: string): GrpcStatus {
  return { code, codeName: CODE_NAMES[code] ?? `CODE_${code}`, details };
}

function metadataToObject(md: unknown): Record<string, string | string[]> {
  const anyMd = md as { getMap?: () => Record<string, unknown> } | undefined;
  if (typeof anyMd?.getMap !== "function") return {};
  const out: Record<string, string | string[]> = {};
  for (const [k, v] of Object.entries(anyMd.getMap())) {
    out[k] = Buffer.isBuffer(v) ? v.toString("base64") : String(v);
  }
  return out;
}

interface AnyCall {
  cancel: () => void;
  write?: (v: unknown) => void;
  end?: () => void;
  on: (ev: string, fn: (...args: unknown[]) => void) => void;
}

/**
 * Invokes one gRPC method. All four streaming kinds converge on a single event
 * log and a single set of termination conditions.
 */
export async function grpcCall(
  target: GrpcTarget,
  options: GrpcSendOptions = {},
): Promise<GrpcResult> {
  const startedAt = Date.now();
  const loaded = await loadGrpc();
  const { grpc } = loaded;
  const method = await resolveMethod(target);

  const warnings = [...method.notes];
  const events: GrpcEvent[] = [];
  const inbound: unknown[] = [];
  let seq = 0;
  let truncated = false;
  let truncatedReason: GrpcTruncatedReason | undefined;
  let error: string | undefined;
  let status: GrpcStatus | undefined;
  let trailers: Record<string, string | string[]> | undefined;

  const emit = (event: Omit<GrpcEvent, "seq" | "at">): void => {
    const full: GrpcEvent = { ...event, seq: seq++, at: Date.now() };
    events.push(full);
    if (!options.onEvent) return;
    try {
      options.onEvent(full);
    } catch {
      // A throwing callback must never take down the call; mirrors http/ws.
    }
  };

  const outbound = options.messages ?? [];
  if (!method.requestStream && outbound.length > 1) {
    warnings.push(
      `${method.kind} accepts a single request message; ` +
        `${outbound.length - 1} extra message(s) were ignored.`,
    );
  }
  if (options.keepWriteOpen && method.kind !== "bidi_streaming") {
    warnings.push(
      `keepWriteOpen only applies to bidi_streaming; ignored for ${method.kind}.`,
    );
  }
  if (
    options.keepWriteOpen &&
    method.kind === "bidi_streaming" &&
    options.maxSessionMs === undefined &&
    options.idleTimeoutMs === undefined &&
    options.maxMessages === undefined &&
    !options.signal &&
    target.deadlineMs === undefined
  ) {
    warnings.push(
      "keepWriteOpen is set with no limit and no deadline; " +
        "the call can only end when the server closes the stream.",
    );
  }

  const credentials = buildCredentials(target, loaded);
  const client = new grpc.Client(
    target.address,
    credentials,
    target.channelOptions as never,
  );

  const md = new grpc.Metadata();
  for (const [k, v] of Object.entries(target.metadata ?? {})) {
    for (const item of Array.isArray(v) ? v : [v]) md.add(k, item);
  }

  const callOptions: Record<string, unknown> = {};
  if (target.deadlineMs !== undefined) {
    callOptions.deadline = new Date(Date.now() + target.deadlineMs);
  }

  await new Promise<void>((resolve) => {
    let settled = false;
    /** Set once the authoritative outcome is known, so late events cannot overwrite it. */
    let outcomeLocked = false;
    let idleTimer: NodeJS.Timeout | undefined;
    let sessionTimer: NodeJS.Timeout | undefined;
    let sendTimer: NodeJS.Timeout | undefined;
    let call: AnyCall | undefined;
    let abortListener: (() => void) | undefined;

    const setOutcome = (next: GrpcStatus, err?: string): void => {
      if (outcomeLocked) return;
      outcomeLocked = true;
      status = next;
      if (err !== undefined && !truncated) error = err;
    };

    const finish = (reason?: GrpcTruncatedReason): void => {
      if (settled) return;
      settled = true;
      if (reason) {
        truncated = true;
        truncatedReason = reason;
      }
      clearTimeout(idleTimer);
      clearTimeout(sessionTimer);
      clearTimeout(sendTimer);
      if (abortListener && options.signal) {
        options.signal.removeEventListener("abort", abortListener);
      }
      try {
        call?.cancel();
      } catch {
        /* already closed */
      }
      try {
        client.close();
      } catch {
        /* already closed */
      }
      resolve();
    };

    const bumpIdle = (): void => {
      if (options.idleTimeoutMs === undefined) return;
      clearTimeout(idleTimer);
      idleTimer = setTimeout(
        () => finish("idle_timeout"),
        options.idleTimeoutMs,
      );
    };

    const onInbound = (payload: unknown): void => {
      if (settled) return;
      inbound.push(payload);
      emit({ direction: "inbound", payload });
      bumpIdle();
      if (
        options.maxMessages !== undefined &&
        inbound.length >= options.maxMessages
      ) {
        finish("max_messages");
      }
    };

    const onCallError = (err: unknown): void => {
      const e = err as { code?: number; message?: string; details?: string };
      setOutcome(
        toStatus(e.code ?? 2, e.details ?? e.message),
        e.message ?? String(err),
      );
      finish();
    };

    if (options.maxSessionMs !== undefined) {
      sessionTimer = setTimeout(
        () => finish("max_session"),
        options.maxSessionMs,
      );
    }

    if (options.signal) {
      if (options.signal.aborted) {
        finish("aborted");
        return;
      }
      abortListener = () => finish("aborted");
      options.signal.addEventListener("abort", abortListener, { once: true });
    }

    const serialize = (v: unknown): Buffer => method.serialize(v);
    const deserialize = (b: Buffer): unknown => method.deserialize(b);

    /** Attaches the listeners every call kind shares. */
    const attachCommon = (target_: AnyCall): void => {
      target_.on("metadata", (initial) => {
        emit({ direction: "meta", metadata: metadataToObject(initial) });
      });
      target_.on("status", (s) => {
        const st = s as { code: number; details?: string; metadata?: unknown };
        trailers = metadataToObject(st.metadata);
        // For unary and client-streaming the callback is authoritative, so the
        // status event only fills in what the callback has not already set.
        setOutcome(toStatus(st.code, st.details));
        emit({ direction: "meta", status: toStatus(st.code, st.details) });
        if (method.responseStream) finish();
      });
    };

    /** Writes the outbound queue, optionally paced, then half-closes. */
    const startWriting = (target_: AnyCall): void => {
      let index = 0;
      const writeNext = (): void => {
        if (settled) return;
        if (index >= outbound.length) {
          const keepOpen =
            options.keepWriteOpen === true && method.kind === "bidi_streaming";
          if (!keepOpen) {
            try {
              target_.end?.();
            } catch {
              /* already closed */
            }
          }
          return;
        }
        const payload = outbound[index++];
        try {
          target_.write?.(payload);
          emit({ direction: "outbound", payload });
        } catch (e) {
          setOutcome(
            toStatus(2, "serialize failed"),
            e instanceof Error ? e.message : String(e),
          );
          finish();
          return;
        }
        if (options.sendIntervalMs) {
          sendTimer = setTimeout(writeNext, options.sendIntervalMs);
        } else {
          writeNext();
        }
      };
      writeNext();
    };

    try {
      if (method.kind === "unary") {
        const payload = outbound[0] ?? {};
        call = client.makeUnaryRequest(
          method.path,
          serialize,
          deserialize,
          payload,
          md,
          callOptions as never,
          (err, value) => {
            if (err) onCallError(err);
            else {
              setOutcome(toStatus(0));
              onInbound(value);
              finish();
            }
          },
        ) as unknown as AnyCall;
        attachCommon(call);
        emit({ direction: "outbound", payload });
      } else if (method.kind === "server_streaming") {
        const payload = outbound[0] ?? {};
        call = client.makeServerStreamRequest(
          method.path,
          serialize,
          deserialize,
          payload,
          md,
          callOptions as never,
        ) as unknown as AnyCall;
        attachCommon(call);
        emit({ direction: "outbound", payload });
        call.on("data", (p) => onInbound(p));
        call.on("error", onCallError);
        call.on("end", () => {
          setOutcome(toStatus(0));
          finish();
        });
      } else if (method.kind === "client_streaming") {
        call = client.makeClientStreamRequest(
          method.path,
          serialize,
          deserialize,
          md,
          callOptions as never,
          (err, value) => {
            if (err) onCallError(err);
            else {
              setOutcome(toStatus(0));
              onInbound(value);
              finish();
            }
          },
        ) as unknown as AnyCall;
        attachCommon(call);
        call.on("error", onCallError);
        startWriting(call);
      } else {
        call = client.makeBidiStreamRequest(
          method.path,
          serialize,
          deserialize,
          md,
          callOptions as never,
        ) as unknown as AnyCall;
        attachCommon(call);
        call.on("data", (p) => onInbound(p));
        call.on("error", onCallError);
        call.on("end", () => {
          setOutcome(toStatus(0));
          finish();
        });
        startWriting(call);
      }
    } catch (e) {
      setOutcome(
        toStatus(2, "call setup failed"),
        e instanceof Error ? e.message : String(e),
      );
      finish();
      return;
    }

    bumpIdle();
  });

  return {
    protocol: "grpc",
    kind: method.kind,
    target,
    events,
    messages: inbound,
    status,
    trailers,
    truncated,
    truncatedReason,
    error,
    warnings,
    durationMs: Date.now() - startedAt,
  };
}
