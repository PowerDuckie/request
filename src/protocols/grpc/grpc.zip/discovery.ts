import { buildCatalog, type Catalog } from "./catalog.js";
import { buildMessageTemplate, type MessageTemplate } from "./template.js";
import { readMethods } from "./descriptor-types.js";
import type { GrpcEndpoint, GrpcMethodKind } from "./types.js";

export interface DiscoveredMethod {
  /** Method name as declared in proto. */
  name: string;
  /** "/pkg.Service/Method" */
  path: string;
  kind: GrpcMethodKind;
  /** Fully-qualified request message name. */
  inputType: string;
  /** Fully-qualified response message name. */
  outputType: string;
  requestStream: boolean;
  responseStream: boolean;
}

export interface DiscoveredService {
  /** Fully-qualified service name. */
  name: string;
  /** Proto package, "" when the service is at the top level. */
  package: string;
  methods: DiscoveredMethod[];
}

export interface DiscoveryResult {
  address: string;
  source: "proto" | "reflection";
  services: DiscoveredService[];
  /** Files loaded, when source === "proto". */
  files?: string[];
  notes: string[];
}

function kindOf(req: boolean, res: boolean): GrpcMethodKind {
  if (req && res) return "bidi_streaming";
  if (req) return "client_streaming";
  if (res) return "server_streaming";
  return "unary";
}

function stripDot(name: string): string {
  return name.startsWith(".") ? name.slice(1) : name;
}

function packageOf(fqService: string): string {
  const idx = fqService.lastIndexOf(".");
  return idx === -1 ? "" : fqService.slice(0, idx);
}

/**
 * Lists every service and method reachable from the endpoint, from the local
 * proto tree or from server reflection. This is the discovery half of the
 * Postman workflow: pick a method, then fill in values.
 */
export async function discover(
  endpoint: GrpcEndpoint,
): Promise<DiscoveryResult> {
  const { catalog, packageDefinition } = await buildCatalog(endpoint);
  const services: DiscoveredService[] = [];

  for (const fqService of catalog.services) {
    const entry = catalog.symbols.get(fqService);
    const methods: DiscoveredMethod[] = [];

    // Preferred path: the ServiceDescriptorProto carries streaming flags and
    // fully-qualified message names.
    const descriptorMethods = entry?.type ? readMethods(entry.type) : [];

    if (descriptorMethods.length > 0) {
      for (const m of descriptorMethods) {
        methods.push({
          name: m.name,
          path: `/${fqService}/${m.name}`,
          kind: kindOf(m.clientStreaming, m.serverStreaming),
          inputType: stripDot(m.inputType),
          outputType: stripDot(m.outputType),
          requestStream: m.clientStreaming,
          responseStream: m.serverStreaming,
        });
      }
    } else {
      // Fallback: the runtime ServiceDefinition. It has the flags and the path
      // but not the message names.
      const def = packageDefinition[fqService];
      if (def && typeof def === "object") {
        for (const [name, raw] of Object.entries(
          def as Record<string, unknown>,
        )) {
          const m = raw as {
            path?: string;
            requestStream?: boolean;
            responseStream?: boolean;
          };
          if (typeof m?.path !== "string") continue;
          methods.push({
            name,
            path: m.path,
            kind: kindOf(m.requestStream === true, m.responseStream === true),
            inputType: "",
            outputType: "",
            requestStream: m.requestStream === true,
            responseStream: m.responseStream === true,
          });
        }
      }
    }

    methods.sort((a, b) => a.name.localeCompare(b.name));
    services.push({ name: fqService, package: packageOf(fqService), methods });
  }

  return {
    address: endpoint.address,
    source: catalog.source,
    services,
    files: catalog.files,
    notes: catalog.notes,
  };
}

export interface MethodDetail extends DiscoveredMethod {
  service: string;
  /** Editable request body plus the structural choices the schema leaves open. */
  request?: MessageTemplate;
  /** Shape of the response, for display. */
  response?: MessageTemplate;
  notes: string[];
}

/**
 * Discovery plus a generated request template, i.e. everything needed to render
 * a request editor for one method.
 */
export async function describeMethod(
  endpoint: GrpcEndpoint,
  service: string,
  method: string,
  options: { includeResponse?: boolean; maxDepth?: number } = {},
): Promise<MethodDetail> {
  const { catalog, packageDefinition } = await buildCatalog(endpoint);
  const detail = describeFromCatalog(
    catalog,
    packageDefinition,
    service,
    method,
    options,
  );
  return detail;
}

export function describeFromCatalog(
  catalog: Catalog,
  packageDefinition: Record<string, unknown>,
  service: string,
  method: string,
  options: { includeResponse?: boolean; maxDepth?: number } = {},
): MethodDetail {
  const entry = catalog.symbols.get(service);
  if (!entry || entry.kind !== "service") {
    throw new Error(
      `service "${service}" not found (source: ${catalog.source}). ` +
        `Available: ${catalog.services.join(", ") || "(none)"}`,
    );
  }

  const notes = [...catalog.notes];
  const descriptorMethods = entry.type ? readMethods(entry.type) : [];

  let found = descriptorMethods.find((m) => m.name === method);
  if (!found) {
    const ci = descriptorMethods.find(
      (m) => m.name.toLowerCase() === method.toLowerCase(),
    );
    if (ci) {
      notes.push(
        `method matched case-insensitively: requested "${method}", using "${ci.name}".`,
      );
      found = ci;
    }
  }

  if (!found) {
    const runtime = packageDefinition[service] as
      | Record<string, unknown>
      | undefined;
    const names = runtime
      ? Object.keys(runtime).sort()
      : descriptorMethods.map((m) => m.name);
    throw new Error(
      `method "${method}" not found on ${service}. Available: ${names.join(", ") || "(none)"}`,
    );
  }

  const base: DiscoveredMethod = {
    name: found.name,
    path: `/${service}/${found.name}`,
    kind: kindOf(found.clientStreaming, found.serverStreaming),
    inputType: stripDot(found.inputType),
    outputType: stripDot(found.outputType),
    requestStream: found.clientStreaming,
    responseStream: found.serverStreaming,
  };

  const request = base.inputType
    ? buildMessageTemplate(catalog, base.inputType, {
        maxDepth: options.maxDepth,
      })
    : undefined;
  const response =
    options.includeResponse && base.outputType
      ? buildMessageTemplate(catalog, base.outputType, {
          maxDepth: options.maxDepth,
        })
      : undefined;

  if (!request) {
    notes.push(
      "request template unavailable: the descriptor did not expose the input type name.",
    );
  }

  return { ...base, service, request, response, notes };
}
