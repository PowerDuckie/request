import { loadGrpc } from "./loader.js";
import { buildCredentials } from "./credentials.js";
import { collectProtoFiles, deriveIncludeDirs } from "./proto-dir.js";
import { fetchDescriptorSet, listServices } from "./reflection.js";
import { isMapEntry } from "./descriptor-types.js";
import type { GrpcEndpoint } from "./types.js";

export const LOADER_OPTIONS = {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
} as const;

export type SymbolKind = "service" | "message" | "enum";

export interface SymbolEntry {
  kind: SymbolKind;
  /** Raw DescriptorProto / EnumDescriptorProto / ServiceDescriptorProto. */
  type: unknown;
}

export interface Catalog {
  source: "proto" | "reflection";
  /** Fully-qualified name (no leading dot) -> entry. */
  symbols: Map<string, SymbolEntry>;
  /** Service names in declaration-independent sorted order. */
  services: string[];
  /** Non-fatal notes worth surfacing to the user. */
  notes: string[];
  /** Files loaded, when source === "proto". */
  files?: string[];
}

const SERVICE_FORMAT = /ServiceDescriptorProto/i;
const MESSAGE_FORMAT = /^Protocol Buffer 3 DescriptorProto$/i;
const ENUM_FORMAT = /EnumDescriptorProto/i;

function classify(value: unknown): SymbolEntry | undefined {
  if (!value || typeof value !== "object") return undefined;
  const v = value as Record<string, unknown>;

  const format = typeof v.format === "string" ? v.format : undefined;
  if (format) {
    if (MESSAGE_FORMAT.test(format)) return { kind: "message", type: v.type };
    if (ENUM_FORMAT.test(format)) return { kind: "enum", type: v.type };
    if (SERVICE_FORMAT.test(format)) return { kind: "service", type: v.type };
    return undefined;
  }

  // A ServiceDefinition is a plain record of method definitions.
  const first = Object.values(v)[0];
  if (first && typeof first === "object" && "path" in (first as object)) {
    return { kind: "service", type: undefined };
  }
  return undefined;
}

/**
 * Builds a catalog from either a local proto tree or server reflection.
 * These are the only two sources of truth; there is no editable intermediate
 * document, because .proto already is the authoritative IDL for gRPC.
 */
export async function buildCatalog(
  endpoint: GrpcEndpoint,
): Promise<{ catalog: Catalog; packageDefinition: Record<string, unknown> }> {
  const loaded = await loadGrpc();
  const { protoLoader } = loaded;
  const notes: string[] = [];

  let packageDefinition: Record<string, unknown>;
  let source: "proto" | "reflection";
  let files: string[] | undefined;

  if (endpoint.reflection) {
    if (endpoint.protoPaths?.length) {
      notes.push(
        "both reflection and protoPaths were provided; reflection wins and protoPaths are ignored.",
      );
    }
    if (typeof protoLoader.loadFileDescriptorSetFromBuffer !== "function") {
      throw new Error(
        "reflection requires @grpc/proto-loader >= 0.7.0 " +
          "(loadFileDescriptorSetFromBuffer is missing).",
      );
    }

    const sessionOptions = {
      address: endpoint.address,
      credentials: buildCredentials(endpoint, loaded),
      metadata: endpoint.metadata,
      timeoutMs: endpoint.reflectionTimeoutMs ?? 5000,
      channelOptions: endpoint.channelOptions,
      version: endpoint.reflectionVersion,
    };

    const advertised = await listServices(sessionOptions);
    if (advertised.length === 0) {
      throw new Error(
        `server at ${endpoint.address} advertises no services via reflection.`,
      );
    }
    const descriptorSet = await fetchDescriptorSet({
      ...sessionOptions,
      symbols: advertised,
    });
    packageDefinition = protoLoader.loadFileDescriptorSetFromBuffer(
      descriptorSet,
      LOADER_OPTIONS,
    ) as unknown as Record<string, unknown>;
    source = "reflection";
    notes.push(`reflection advertised ${advertised.length} service(s).`);
  } else {
    if (!endpoint.protoPaths?.length) {
      throw new Error(
        "grpc endpoint requires protoPaths (files or directories) or reflection: true.",
      );
    }
    files = await collectProtoFiles({
      paths: endpoint.protoPaths,
      ignoreDirs: endpoint.ignoreDirs,
      followSymlinks: endpoint.followSymlinks,
    });
    const includeDirs = endpoint.includeDirs?.length
      ? endpoint.includeDirs
      : deriveIncludeDirs(files, endpoint.protoPaths);

    packageDefinition = (await protoLoader.load(files, {
      ...LOADER_OPTIONS,
      includeDirs,
    })) as unknown as Record<string, unknown>;
    source = "proto";
    if (files.length > 1) {
      notes.push(
        `merged ${files.length} .proto file(s) from ${endpoint.protoPaths.length} path(s).`,
      );
    }
  }

  const symbols = new Map<string, SymbolEntry>();
  const services: string[] = [];

  for (const [name, value] of Object.entries(packageDefinition)) {
    const entry = classify(value);
    if (!entry) continue;
    if (entry.kind === "message" && isMapEntry(entry.type)) continue;
    symbols.set(name, entry);
    if (entry.kind === "service") services.push(name);
  }

  services.sort();

  return {
    catalog: { source, symbols, services, notes, files },
    packageDefinition,
  };
}
