import { buildCatalog } from "./catalog.js";
import type { GrpcMethodKind, GrpcTarget } from "./types.js";

export interface ResolvedMethod {
  kind: GrpcMethodKind;
  /** "/pkg.Service/Method" */
  path: string;
  requestStream: boolean;
  responseStream: boolean;
  serialize: (value: unknown) => Buffer;
  deserialize: (buffer: Buffer) => unknown;
  /** How the descriptor was obtained. */
  source: "proto" | "reflection";
  /** Non-fatal notes worth surfacing. */
  notes: string[];
}

function kindOf(req: boolean, res: boolean): GrpcMethodKind {
  if (req && res) return "bidi_streaming";
  if (req) return "client_streaming";
  if (res) return "server_streaming";
  return "unary";
}

/**
 * Resolves one method to the codecs and streaming flags needed to invoke it.
 *
 * The streaming kind has exactly one source — the descriptor — and is never
 * accepted from the caller, so a mismatch between declaration and runtime
 * behaviour is not representable.
 */
export async function resolveMethod(
  target: GrpcTarget,
): Promise<ResolvedMethod> {
  const { catalog, packageDefinition } = await buildCatalog(target);
  const notes = [...catalog.notes];

  const serviceDef = packageDefinition[target.service];
  if (!serviceDef || typeof serviceDef !== "object") {
    throw new Error(
      `service "${target.service}" not found (source: ${catalog.source}). ` +
        `Available: ${catalog.services.join(", ") || "(none)"}`,
    );
  }

  const def = serviceDef as Record<string, unknown>;
  const methodNames = Object.keys(def).filter((k) => {
    const v = def[k] as { path?: unknown } | undefined;
    return typeof v?.path === "string";
  });

  let methodKey = methodNames.find((k) => k === target.method);
  if (!methodKey) {
    methodKey = methodNames.find(
      (k) => k.toLowerCase() === target.method.toLowerCase(),
    );
    if (methodKey) {
      notes.push(
        `method matched case-insensitively: requested "${target.method}", using "${methodKey}".`,
      );
    }
  }
  if (!methodKey) {
    throw new Error(
      `method "${target.method}" not found on ${target.service}. ` +
        `Available: ${methodNames.sort().join(", ") || "(none)"}`,
    );
  }

  const m = def[methodKey] as {
    path: string;
    requestStream: boolean;
    responseStream: boolean;
    requestSerialize: (v: unknown) => Buffer;
    responseDeserialize: (b: Buffer) => unknown;
  };

  if (
    typeof m.requestSerialize !== "function" ||
    typeof m.responseDeserialize !== "function"
  ) {
    throw new Error(
      `method "${target.service}/${methodKey}" has no usable codecs; ` +
        `the descriptor source may be incomplete.`,
    );
  }

  return {
    kind: kindOf(m.requestStream === true, m.responseStream === true),
    path: m.path,
    requestStream: m.requestStream === true,
    responseStream: m.responseStream === true,
    serialize: m.requestSerialize,
    deserialize: m.responseDeserialize,
    source: catalog.source,
    notes,
  };
}
