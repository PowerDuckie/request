import { loadGrpc } from "./loader.js";

/* ------------------------------------------------------------------ *
 * Minimal protobuf wire codec.
 * Only what the reflection service needs: varint, length-delimited.
 * ------------------------------------------------------------------ */

function encodeVarint(value: number): Buffer {
  const bytes: number[] = [];
  let v = value;
  while (v > 0x7f) {
    bytes.push((v & 0x7f) | 0x80);
    v = Math.floor(v / 128);
  }
  bytes.push(v);
  return Buffer.from(bytes);
}

function tag(field: number, wire: number): Buffer {
  return encodeVarint(field * 8 + wire);
}

function lengthDelimited(field: number, payload: Buffer): Buffer {
  return Buffer.concat([tag(field, 2), encodeVarint(payload.length), payload]);
}

interface Cursor {
  buf: Buffer;
  pos: number;
}

function readVarint(c: Cursor): number {
  let result = 0;
  let shift = 0;
  for (;;) {
    if (c.pos >= c.buf.length) throw new Error("truncated varint");
    const byte = c.buf[c.pos++];
    result += (byte & 0x7f) * 2 ** shift;
    if ((byte & 0x80) === 0) break;
    shift += 7;
    if (shift > 63) throw new Error("varint too long");
  }
  return result;
}

function readBytes(c: Cursor): Buffer {
  const len = readVarint(c);
  if (c.pos + len > c.buf.length)
    throw new Error("truncated length-delimited field");
  const out = c.buf.subarray(c.pos, c.pos + len);
  c.pos += len;
  return out;
}

function skipField(c: Cursor, wire: number): void {
  switch (wire) {
    case 0:
      readVarint(c);
      return;
    case 1:
      c.pos += 8;
      return;
    case 2:
      c.pos += readVarint(c);
      return;
    case 5:
      c.pos += 4;
      return;
    default:
      throw new Error(`unsupported wire type ${wire}`);
  }
}

function* fields(
  buf: Buffer,
): Generator<{ field: number; wire: number; c: Cursor }> {
  const c: Cursor = { buf, pos: 0 };
  while (c.pos < buf.length) {
    const key = readVarint(c);
    yield { field: Math.floor(key / 8), wire: key & 7, c };
  }
}

/* ------------------------------------------------------------------ *
 * ServerReflectionRequest encoders
 * ------------------------------------------------------------------ */

function encodeFilenameRequest(filename: string, host = ""): Buffer {
  const parts: Buffer[] = [];
  if (host) parts.push(lengthDelimited(1, Buffer.from(host, "utf8")));
  parts.push(lengthDelimited(3, Buffer.from(filename, "utf8")));
  return Buffer.concat(parts);
}

function encodeSymbolRequest(symbol: string, host = ""): Buffer {
  const parts: Buffer[] = [];
  if (host) parts.push(lengthDelimited(1, Buffer.from(host, "utf8")));
  parts.push(lengthDelimited(4, Buffer.from(symbol, "utf8")));
  return Buffer.concat(parts);
}

function encodeListServicesRequest(host = ""): Buffer {
  const parts: Buffer[] = [];
  if (host) parts.push(lengthDelimited(1, Buffer.from(host, "utf8")));
  // list_services = 7; the string value is ignored by servers.
  parts.push(lengthDelimited(7, Buffer.from("*", "utf8")));
  return Buffer.concat(parts);
}

/* ------------------------------------------------------------------ *
 * ServerReflectionResponse decoders
 * ------------------------------------------------------------------ */

interface ReflectionReply {
  fileDescriptors: Buffer[];
  services?: string[];
  errorCode?: number;
  errorMessage?: string;
}

function decodeReflectionResponse(buf: Buffer): ReflectionReply {
  const reply: ReflectionReply = { fileDescriptors: [] };
  for (const { field, wire, c } of fields(buf)) {
    if (field === 4 && wire === 2) {
      // FileDescriptorResponse { repeated bytes file_descriptor_proto = 1; }
      const inner = readBytes(c);
      for (const f of fields(inner)) {
        if (f.field === 1 && f.wire === 2) {
          reply.fileDescriptors.push(Buffer.from(readBytes(f.c)));
        } else skipField(f.c, f.wire);
      }
    } else if (field === 6 && wire === 2) {
      // ListServiceResponse { repeated ServiceResponse service = 1; }
      const inner = readBytes(c);
      const names: string[] = [];
      for (const f of fields(inner)) {
        if (f.field === 1 && f.wire === 2) {
          const svc = readBytes(f.c);
          for (const g of fields(svc)) {
            if (g.field === 1 && g.wire === 2) {
              names.push(readBytes(g.c).toString("utf8"));
            } else skipField(g.c, g.wire);
          }
        } else skipField(f.c, f.wire);
      }
      reply.services = names;
    } else if (field === 7 && wire === 2) {
      // ErrorResponse { int32 error_code = 1; string error_message = 2; }
      const inner = readBytes(c);
      for (const f of fields(inner)) {
        if (f.field === 1 && f.wire === 0) reply.errorCode = readVarint(f.c);
        else if (f.field === 2 && f.wire === 2) {
          reply.errorMessage = readBytes(f.c).toString("utf8");
        } else skipField(f.c, f.wire);
      }
    } else {
      skipField(c, wire);
    }
  }
  return reply;
}

/** FileDescriptorProto { string name = 1; repeated string dependency = 3; } */
function readDescriptorMeta(buf: Buffer): { name: string; deps: string[] } {
  let name = "";
  const deps: string[] = [];
  for (const { field, wire, c } of fields(buf)) {
    if (field === 1 && wire === 2) name = readBytes(c).toString("utf8");
    else if (field === 3 && wire === 2)
      deps.push(readBytes(c).toString("utf8"));
    else skipField(c, wire);
  }
  return { name, deps };
}

/* ------------------------------------------------------------------ *
 * Session
 * ------------------------------------------------------------------ */

export interface ReflectionSessionOptions {
  address: string;
  credentials: unknown;
  metadata?: Record<string, string | string[]>;
  timeoutMs?: number;
  channelOptions?: Record<string, unknown>;
  version?: "v1" | "v1alpha";
}

const REFLECTION_PATHS = {
  v1: "/grpc.reflection.v1.ServerReflection/ServerReflectionInfo",
  v1alpha: "/grpc.reflection.v1alpha.ServerReflection/ServerReflectionInfo",
} as const;

type ReflectionOp = { kind: "list" } | { kind: "symbols"; symbols: string[] };

interface ReflectionOutcome {
  services?: string[];
  /** filename -> raw FileDescriptorProto */
  descriptors: Map<string, Buffer>;
  version: "v1" | "v1alpha";
}

async function withVersionFallback(
  options: ReflectionSessionOptions,
  op: ReflectionOp,
): Promise<ReflectionOutcome> {
  const versions: Array<"v1" | "v1alpha"> = options.version
    ? [options.version]
    : ["v1", "v1alpha"];

  let last: Error | undefined;
  for (const version of versions) {
    try {
      return await runSession(options, op, version);
    } catch (e) {
      last = e instanceof Error ? e : new Error(String(e));
      const unimplemented =
        /UNIMPLEMENTED/i.test(last.message) || /\bcode 12\b/.test(last.message);
      if (!unimplemented) throw last;
    }
  }
  throw new Error(
    `server reflection unavailable at ${options.address}: ${last?.message ?? "unknown"}`,
    { cause: last },
  );
}

async function runSession(
  options: ReflectionSessionOptions,
  op: ReflectionOp,
  version: "v1" | "v1alpha",
): Promise<ReflectionOutcome> {
  const { grpc } = await loadGrpc();
  const client = new grpc.Client(
    options.address,
    options.credentials as never,
    options.channelOptions as never,
  );

  const md = new grpc.Metadata();
  for (const [k, v] of Object.entries(options.metadata ?? {})) {
    for (const item of Array.isArray(v) ? v : [v]) md.add(k, item);
  }

  const callOptions: Record<string, unknown> = {};
  if (options.timeoutMs !== undefined) {
    callOptions.deadline = new Date(Date.now() + options.timeoutMs);
  }

  const call = client.makeBidiStreamRequest(
    REFLECTION_PATHS[version],
    (v: Buffer) => v,
    (b: Buffer) => b,
    md,
    callOptions as never,
  ) as unknown as {
    write: (b: Buffer) => void;
    end: () => void;
    cancel: () => void;
    on: (ev: string, fn: (...a: unknown[]) => void) => void;
  };

  const descriptors = new Map<string, Buffer>();
  const requested = new Set<string>();
  let outstanding = 0;
  let services: string[] | undefined;

  return await new Promise<ReflectionOutcome>(
    (resolvePromise, rejectPromise) => {
      let settled = false;

      const fail = (err: Error): void => {
        if (settled) return;
        settled = true;
        try {
          call.cancel();
        } catch {
          /* already closed */
        }
        client.close();
        rejectPromise(err);
      };

      const succeed = (): void => {
        if (settled) return;
        settled = true;
        try {
          call.end();
        } catch {
          /* already closed */
        }
        client.close();
        resolvePromise({ services, descriptors, version });
      };

      /**
       * Requests are tracked by count, not paired to replies: we only care
       * whether anything is still in flight, which makes this correct even if a
       * server answers out of order.
       */
      const ask = (key: string, payload: Buffer): void => {
        if (requested.has(key)) return;
        requested.add(key);
        outstanding += 1;
        call.write(payload);
      };

      call.on("data", (chunk) => {
        if (settled) return;
        outstanding = Math.max(0, outstanding - 1);

        let reply: ReflectionReply;
        try {
          reply = decodeReflectionResponse(chunk as Buffer);
        } catch (e) {
          fail(new Error(`malformed reflection response: ${String(e)}`));
          return;
        }

        if (reply.errorCode !== undefined && reply.errorCode !== 0) {
          fail(
            new Error(
              `reflection error ${reply.errorCode}: ${reply.errorMessage ?? "(no message)"}`,
            ),
          );
          return;
        }

        if (reply.services) services = reply.services;

        for (const fd of reply.fileDescriptors) {
          const meta = readDescriptorMeta(fd);
          if (!meta.name || descriptors.has(meta.name)) continue;
          descriptors.set(meta.name, fd);
          for (const dep of meta.deps) {
            if (!descriptors.has(dep))
              ask(`file:${dep}`, encodeFilenameRequest(dep));
          }
        }

        if (outstanding === 0) succeed();
      });

      call.on("error", (err) => fail(err as Error));
      call.on("status", (s) => {
        const st = s as { code: number; details?: string };
        if (st.code !== 0 && !settled) {
          fail(
            new Error(
              `reflection stream ended: code ${st.code} ${st.details ?? ""}`,
            ),
          );
        }
      });

      if (op.kind === "list") ask("list", encodeListServicesRequest());
      else
        for (const sym of op.symbols)
          ask(`sym:${sym}`, encodeSymbolRequest(sym));
    },
  );
}

/* ------------------------------------------------------------------ *
 * Public API
 * ------------------------------------------------------------------ */

/** FileDescriptorSet { repeated FileDescriptorProto file = 1; } */
export function serializeDescriptorSet(
  descriptors: Map<string, Buffer>,
): Buffer {
  return Buffer.concat(
    [...descriptors.values()].map((d) => lengthDelimited(1, d)),
  );
}

/** Service names exposed by the server, excluding the reflection service itself. */
export async function listServices(
  options: ReflectionSessionOptions,
): Promise<string[]> {
  const { services } = await withVersionFallback(options, { kind: "list" });
  return (services ?? [])
    .filter((n) => !n.startsWith("grpc.reflection."))
    .sort();
}

/** Transitive descriptor closure for the given symbols, merged and de-duplicated. */
export async function fetchDescriptorSet(
  options: ReflectionSessionOptions & { symbols: string[] },
): Promise<Buffer> {
  if (options.symbols.length === 0) {
    throw new Error("fetchDescriptorSet requires at least one symbol.");
  }
  const { descriptors } = await withVersionFallback(options, {
    kind: "symbols",
    symbols: options.symbols,
  });
  return serializeDescriptorSet(descriptors);
}

/** Lists services, then fetches the descriptor closure for all of them. */
export async function fetchFullDescriptorSet(
  options: ReflectionSessionOptions,
): Promise<{ services: string[]; descriptorSet: Buffer }> {
  const services = await listServices(options);
  if (services.length === 0)
    return { services, descriptorSet: Buffer.alloc(0) };
  const descriptorSet = await fetchDescriptorSet({
    ...options,
    symbols: services,
  });
  return { services, descriptorSet };
}
